// --1--
// 1) написати об*єкт студента який буде виводити ім*я, спеціальнісь, середній
// бал і кількість пропущених занять
// 2) написати метод який буде виводити цю інформацію
// 3) написати три варіанти студентів
// 4) прикріпити знначення за допомогою call apply bind

// 1)
// let student = {
//   name: "Dima",
//   major: "Audit",
//   gpa: 4,
//   missedClasses: 1
// };

// 2)
// let student = {
//   name: "Dima",
//   major: "Audit",
//   gpa: 4,
//   missedClasses: 1,
//   showInfo: function() {
//     console.log(`Name: ${this.name}, Major: ${this.major}, GPA: ${this.gpa}, Missed Classes: ${this.missedClasses}`);
//   }
// };

// 3)
// let student1 = {
//   name: "Dima",
//   major: "Audit",
//   gpa: 4,
//   missedClasses: 1,
//   showInfo: function() {
//     console.log(`Name: ${this.name}, Major: ${this.major}, GPA: ${this.gpa}, Missed Classes: ${this.missedClasses}`);
//   }
// };

// let student2 = {
//   name: "Maksym",
//   major: "Psychology",
//   gpa: 3,
//   missedClasses: 2,
//   showInfo: function() {
//     console.log(`Name: ${this.name}, Major: ${this.major}, GPA: ${this.gpa}, Missed Classes: ${this.missedClasses}`);
//   }
// };

// let student3 = {
//   name: "Mark",
//   major: "History",
//   gpa: 2,
//   missedClasses: 10,
//   showInfo: function() {
//     console.log(`Name: ${this.name}, Major: ${this.major}, GPA: ${this.gpa}, Missed Classes: ${this.missedClasses}`);
//   }
// };

// 4)
// const student1 = {
//   name: "Dima",
//   major: "Audit",
//   gpa: 4,
//   missedClasses: 1,
//   showInfo: function() {
//     console.log(`Name: ${this.name}, Major: ${this.major}, GPA: ${this.GPA}, Missed Classes: ${this.missedClasses}`);
//   }
// };

// student1.showInfo.call();

// const student2 = {
//   name: "Maksym",
//   major: "Psychology",
//   gpa: 3,
//   missedClasses: 2,
//   showInfo: function() {
//     console.log(`Name: ${this.name}, Major: ${this.major}, GPA: ${this.GPA}, Missed Classes: ${this.missedClasses}`);
//   }
// };

// student2.showInfo.apply();

// const student3 = {
//     name: "Mark",
//   major: "History",
//   gpa: 2,
//   missedClasses: 10,
//   showInfo: function() {
//     console.log(`Name: ${this.name}, Major: ${this.major}, GPA: ${this.GPA}, Missed Classes: ${this.missedClasses}`);
//   }
// };

// const showInfoStudent3 = student3.showInfo.bind(student3);
// showInfoStudent3();

// --2--
// Написати дві кнопки і закріпити на них функції
// при натисканні на кнопку html - має видати коротке визначення що це таке при натисканні на кнопку css - має видати коротке визначення що це таке

// function displayHtml() {
//   alert('HTML stands for Hyper Text Markup Language.');
// }

// function displayCss() {
//   alert('CSS stands for Cascading Style Sheets.');
// }

// document.querySelector('#htmlButton').addEventListener('click', displayHtml);
// document.querySelector('#cssButton').addEventListener('click', displayCss);

//  --3--
// Написати функцію магазин, яка отримує назву товару, ціну за кг і кількість товару функція має повертати назву товару і вартість
// перевірити на варіантах:
// 1) banana 30, 4, 5
// 2) cherry 58, 1,3
// 3) orange 89. 3,4

// function shop(product, pricePerKg, quantity) {
//   const total = parseFloat(pricePerKg) * parseFloat(quantity);
//   return `${product}: ${total.toFixed(2)}`;
// }

// console.log(shop("banana", "30", "4.5"));
// console.log(shop("cherry", "58", "1.3"));
// console.log(shop("orange", "89", "3.4"));
