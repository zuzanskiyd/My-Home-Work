// Домашнє завдання
// -----1----
// Напишіть такий JavaScript, щоб після натискання на кнопку button, елемент
// <div id="text"> зникав.

// document.addEventListener('DOMContentLoaded', function () {
//   const hideButton = document.getElementById('hide-button');
//   const textElement = document.getElementById('text');

//   hideButton.addEventListener('click', function () {
//     textElement.style.display = 'none';
//   });
// });

// -----2----
// Напишіть такий код, щоб після натискання на кнопку, вона зникала.

// const button = document.getElementById('myButton');

// button.addEventListener('click', () => {
//   button.style.display = 'none';
// });

// -----3----
// Створіть дерево, яке показує/приховує дочірні вузли при кліці

// const parents = document.querySelectorAll('.parent');

// parents.forEach(parent => {
//   parent.addEventListener('click', function () {
//     this.classList.toggle('open');
//     const children = this.querySelectorAll('.child');
//     children.forEach(child => {
//       child.classList.toggle('show');
//     });
//   });
// });
